
//#include "stdafx.h"

#include "cv.h"
#include "highgui.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <time.h>
#include <ctype.h>




static CvMemStorage* storage = 0;
static CvHaarClassifierCascade* cascade = 0;

void detect_and_draw( IplImage* image, IplImage* imgAnterior );
bool analizarFlujo( IplImage* image, IplImage* imgAnterior, CvRect rect);

const char* cascadeFile ="/home/mrc/ProyectosQt/Guda/haartTraining/haartPuro/profe.xml";
const char* aviFile ="/home/mrc/ProyectosQt/Guda/haartTraining/haartPuro/ca3.avi";

const int MAX_CORNERS = 100;

CvPoint2D32f* cornersA = new CvPoint2D32f[ MAX_CORNERS ];
CvPoint2D32f* cornersB = new CvPoint2D32f[ MAX_CORNERS ];
char features_found[ MAX_CORNERS ];
float feature_errors[ MAX_CORNERS ];
IplImage* pyrA;
IplImage* pyrB;

int main(void) {
    CvCapture* capture = 0;
    IplImage *frame, *frame_copy = 0;
    IplImage *frameAnterior;
    cascade = (CvHaarClassifierCascade*)cvLoad(cascadeFile, 0, 0, 0 );

    if( !cascade )
    {
        fprintf( stderr,"ERROR: Could not load classifier cascade\n" );
        fprintf( stderr,"Usage: facedetect --cascade=\"<cascade_path>\" [filename|camera_index]\n" );
    }
    storage = cvCreateMemStorage(0);

    /*
    if( !input_name || (isdigit(input_name[0]) && input_name[1] == '\0') )
        capture = cvCaptureFromCAM( !input_name ? 0 : input_name[0] - '0' );
    else
        capture = cvCaptureFromAVI( input_name );
    */

    //capture = cvCaptureFromCAM(0);

    capture = cvCaptureFromAVI(aviFile);

    cvNamedWindow( "Detecta", 1 );

    if (capture) {
        for(;;) {
            if( !cvGrabFrame( capture ))
                break;
            frame = cvRetrieveFrame( capture );
            if( !frame )
                break;
            if( !frame_copy ) {
                frame_copy = cvCreateImage( cvSize(frame->width,frame->height),
                                            IPL_DEPTH_8U, frame->nChannels );
                frameAnterior = cvCreateImage( cvSize(frame->width,frame->height),
                                        IPL_DEPTH_8U, frame->nChannels );
            }
            if( frame->origin == IPL_ORIGIN_TL ) {
                cvCopy( frame, frame_copy, 0 );
            } else {
                cvFlip( frame, frame_copy, 0 );
            }

            detect_and_draw(frame_copy, frameAnterior);

            if( cvWaitKey( 100 ) >= 0 ){
                break;
            }
            cvWaitKey(500);
            cvCopy(frame, frameAnterior, 0);
        }

        cvReleaseImage( &frame_copy );
        cvReleaseImage( &frameAnterior );
        cvReleaseCapture( &capture );
    }
    cvDestroyWindow("Detecta");
}

bool analizarFlujo(IplImage *img, IplImage *imgAnterior, CvRect *rect) {

        cvSetImageROI(img, *rect);
        IplImage *imgA1 = cvCreateImage(cvGetSize(img), img->depth, img->nChannels);
        cvCopy(imgA1, img);

        cvSetImageROI(imgAnterior, *rect);
        IplImage *imgB1 = cvCreateImage(cvGetSize(imgAnterior), imgAnterior->depth, imgAnterior->nChannels);
        cvCopy(imgB1, imgAnterior);

        cvResetImageROI(img);
        cvResetImageROI(imgAnterior);

        cvNamedWindow( "img", 1 );
        cvNamedWindow( "imgA", 1 );
        cvShowImage( "img", img );
        cvShowImage( "imgA", imgAnterior );


        int py = imgA1->height;
        int px = imgA1->width;
        IplImage *imgA=cvCreateImage( cvSize(px,py),IPL_DEPTH_8U, 1);
        IplImage *imgB=cvCreateImage( cvSize(px,py),IPL_DEPTH_8U, 1);
        cvCvtColor( imgA1, imgA, CV_BGR2GRAY ); //
        cvCvtColor( imgB1, imgB, CV_BGR2GRAY ); //

        CvSize img_sz = cvGetSize( imgA );

        /////////////////////////////
        IplImage *eig_image = cvCreateImage( img_sz, IPL_DEPTH_32F, 1 );
        IplImage *tmp_image = cvCreateImage( img_sz, IPL_DEPTH_32F, 1 );
        int corner_count = MAX_CORNERS;
        CvSize pyr_sz;
        int win_size = 5;


        cvGoodFeaturesToTrack(imgA,eig_image,tmp_image,cornersA,&corner_count,0.01,5.0,0,3,0,0.04);
        cvFindCornerSubPix(imgA,cornersA,corner_count,cvSize(win_size,win_size),cvSize(-1,-1),cvTermCriteria(CV_TERMCRIT_ITER|CV_TERMCRIT_EPS,20,1));
        // Call the Lucas Kanade algorithm

        pyr_sz = cvSize( imgA->width+8, imgB->height/3 );
        pyrA = cvCreateImage( pyr_sz, IPL_DEPTH_32F, 1 );
        pyrB = cvCreateImage( pyr_sz, IPL_DEPTH_32F, 1 );

        cvCalcOpticalFlowPyrLK(imgA,imgB,pyrA,pyrB,cornersA,cornersB,corner_count,cvSize( win_size,win_size ),5,features_found,feature_errors,cvTermCriteria( CV_TERMCRIT_ITER | CV_TERMCRIT_EPS, 20, .03 ),0);
        // Now make some image of what we are looking at:
        float dx=0.0;

        for( int i=0; i<corner_count; i++ )
        {
            if( features_found[i]==0|| feature_errors[i]>100 ) {continue;}

            dx=sqrt((cornersA[i].x-cornersB[i].x)*(cornersA[i].x-cornersB[i].x)+(cornersA[i].y-cornersB[i].y)*(cornersA[i].y-cornersB[i].y));
            if(dx>1 && dx<50){
                return true;
            }
        }

}


void detect_and_draw( IplImage* img, IplImage* imgAnterior ) {
    static CvScalar colors[] = {
        {{0,0,255}},
        {{0,128,255}},
        {{0,255,255}},
        {{0,255,0}},
        {{255,128,0}},
        {{255,255,0}},
        {{255,0,0}},
        {{255,0,255}}
    };

    double scale = 1.3;
    IplImage* gray = cvCreateImage( cvSize(img->width,img->height), 8, 1 );
    IplImage* small_img = cvCreateImage( cvSize( cvRound (img->width/scale),
                         cvRound (img->height/scale)),
                     8, 1 );
    int i;

    cvCvtColor( img, gray, CV_BGR2GRAY );
    cvResize( gray, small_img, CV_INTER_LINEAR );
    cvEqualizeHist( small_img, small_img );
    cvClearMemStorage( storage );

    if(cascade) {
        double t = (double)cvGetTickCount();
        CvSeq* faces = cvHaarDetectObjects(small_img, cascade, storage,
                                            1.1, 2, 0/*CV_HAAR_DO_CANNY_PRUNING*/,
                                            cvSize(30, 30) );
        t = (double)cvGetTickCount() - t;
        printf( "detection time = %gms\n", t/((double)cvGetTickFrequency()*100.) );
        for( i = 0; i < (faces ? faces->total : 0); i++ ) {
            CvRect* r = (CvRect*)cvGetSeqElem( faces, i );
            if (analizarFlujo(img, imgAnterior, r)) {
                CvPoint center;
                int radius;
                center.x = cvRound((r->x + r->width*0.5)*scale);
                center.y = cvRound((r->y + r->height*0.5)*scale);
                radius = cvRound((r->width + r->height)*0.25*scale);
                cvCircle( img, center, radius, colors[i%8], 3, 8, 0 );
            }
        }
    }
    cvShowImage( "Detecta", img );
    cvReleaseImage( &gray );
    cvReleaseImage( &small_img );
}
